// app.js
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 获取用户当前登录信息
    wx.login({
      success(res){
        console.log('wx.login得到的数据',res)
      }
    })
 
    //获得用户当前设置权限
    let that=this
    wx.getSetting({
      success(res){
        console.log('wx.getSetting得到的数据',res)
        if (res.authSetting["scope.userInfo"]){//查看是否可以从getUserInfo获取用户信息；
          wx.getUserInfo({
            success(res){
              console.log("wx.getUserInfo得到的数据",res)
           
              that.globalData.userInfo = res.userInfo //用户信息复制给全局，供全部JS文件使用；
              
            }
          })
        }
      }
    })
    





  },

  
  globalData: {
    userInfo: null
  }
})
