// pages/partner/partner.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
    username:"小雨",

    // <!-- 选择器，连接都可以从js中动态获取 -->
    id: 233,
    itemurl:"/pages/home/imgshow/imgshow",
    itemclass:"event-item",
    imagesrc: "https://hackwork.oss-cn-shanghai.aliyuncs.com/lesson/weapp/4/weapp.jpg",
    imagemode:"widthFix",
    imagewidth:"100%",
    // 列表数据
    newstitle:[
        "瑞幸咖啡：有望在三季度达到门店运营的盈亏平衡点",
        "腾讯：广告高库存量还是会持续到下一年",
  
      ],

    // 条件渲染
    female:10
      
    
    
    },
  

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})